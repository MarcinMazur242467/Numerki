class Solver:
    def __init__(self, function, rangeL, rangeR, epsilon, iterations):
        self.function = function
        self.rangeL = rangeL
        self.rangeR = rangeR
        self.epsilon = epsilon
        self.iterations = iterations

    def solveE(self):
        pass

    def solveI(self):
        pass
